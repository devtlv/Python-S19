from landing_python import app

@app.route('/')
def homepage():
    return "Hello world, welcome to my landing page !"


