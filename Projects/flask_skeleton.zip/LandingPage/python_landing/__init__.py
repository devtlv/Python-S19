import flask

app = flask.Flask(__name__)

from python_landing import routes, models
